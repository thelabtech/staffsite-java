package org.alt60m.crs.model;

import com.kenburcham.framework.dbio.DBIOEntity;
import com.kenburcham.framework.dbio.DBIOEntityException;
import java.util.*;

public class Conference extends DBIOEntity{
	//IDENTITY
	private int conferenceID = 0;
	
	//KEY

	private Date createDate = null;
	private String name = "";
	private String theme = "";
	private String password = "";
	private String staffPassword = "";
	private String region = "";
	private String briefDescription = "";
	private String contactName = "";
	private String contactEmail = "";
	private String contactPhone = "";
	private String contactAddress1 = "";
	private String contactAddress2 = "";
	private String contactCity = "";
	private String contactState = "";
	private String contactZip = "";
	private String splashPageURL = "";
	private String acceptVisa = "";
	private String acceptMasterCard = "";
	private String acceptAmericanExpress = "";
	private String acceptDiscover = "";
	private String acceptScholarships = "";
	private String acceptEChecks = "";
	private String authnetPassword = "";
	private Date preRegStart = null;
	private Date preRegEnd = null;
	private Date defaultDateStaffArrive = null;
	private Date defaultDateStaffLeave = null;
	private Date defaultDateGuestArrive = null;
	private Date defaultDateGuestLeave = null;
	private float onsiteCost = 0;
	private float commuterCost = 0;
	private float preRegDeposit = 0;
	private float discountFullPayment = 0;
	private float discountEarlyReg = 0;
	private Date discountEarlyRegDate = null;
	private String checkPayableTo = "";
	private String merchantAcctNum = "";
	private String confirmationEmail = "";

	private String confImageID = "";
	private String fontFace = "";
	private String backgroundColor = "";
	private String backgroundColor2 = "";
	private String backgroundColor3 = "";
	private String foregroundColor = "";
	private String highlightColor = "";
	private String highlightColor2 = "";
	private String requiredColor = "";

	public void localinit() throws DBIOEntityException {
		String table = "crs_Conference";

		setMetadata("ConferenceID","conferenceID","IDENTITY");

		setMetadata("Name","name",table);
		setMetadata("Theme","theme",table);
		setMetadata("Password","password",table);
		setMetadata("StaffPassword","staffPassword",table);
		setMetadata("Region","region",table);
		setMetadata("BriefDescription","briefDescription",table);
		setMetadata("ContactName","contactName",table);
		setMetadata("ContactEmail","contactEmail",table);
		setMetadata("ContactPhone","contactPhone",table);
		setMetadata("ContactAddress1","contactAddress1",table);
		setMetadata("ContactAddress2","contactAddress2",table);
		setMetadata("ContactCity","contactCity",table);
		setMetadata("ContactState","contactState",table);
		setMetadata("ContactZip","contactZip",table);
		setMetadata("SplashPageURL","splashPageURL",table);
		setMetadata("AcceptVisaString","acceptVisa",table);
		setMetadata("AcceptMasterCardString","acceptMasterCard",table);
		setMetadata("AcceptAmericanExpressString","acceptAmericanExpress",table);
		setMetadata("AcceptDiscoverString","acceptDiscover",table);
		setMetadata("AcceptScholarshipsString","acceptScholarships",table);
		setMetadata("AcceptEChecksString","acceptEChecks",table);
		setMetadata("AuthnetPassword","authnetPassword",table);
		setMetadata("PreRegStart","preRegStart",table);
		setMetadata("PreRegEnd","preRegEnd",table);
		setMetadata("DefaultDateStaffArrive","defaultDateStaffArrive",table);
		setMetadata("DefaultDateStaffLeave","defaultDateStaffLeave",table);
		setMetadata("DefaultDateGuestArrive","defaultDateGuestArrive",table);
		setMetadata("DefaultDateGuestLeave","defaultDateGuestLeave",table);
		setMetadata("OnsiteCost","onsiteCost",table);
		setMetadata("CommuterCost","commuterCost",table);
		setMetadata("PreRegDeposit","preRegDeposit",table);
		setMetadata("DiscountFullPayment","discountFullPayment",table);
		setMetadata("DiscountEarlyReg","discountEarlyReg",table);
		setMetadata("DiscountEarlyRegDate","discountEarlyRegDate",table);
		setMetadata("CheckPayableTo","checkPayableTo",table);
		setMetadata("MerchantAcctNum","merchantAcctNum",table);
		setMetadata("ConfImageID","confImageID",table);
		setMetadata("FontFace","fontFace",table);
		setMetadata("BackgroundColor","backgroundColor",table);
		setMetadata("ForegroundColor","foregroundColor",table);
		setMetadata("HighlightColor","highlightColor",table);
		setMetadata("BackgroundColor2","backgroundColor2",table);
		setMetadata("BackgroundColor3","backgroundColor3",table);
		setMetadata("RequiredColor","requiredColor",table);
		setMetadata("HighlightColor2","highlightColor2",table);
		setMetadata("ConfirmationEmail","confirmationEmail",table);

// For migration
		setMetadata("AcceptCreditCardsString","acceptCreditCards",table);

		setAutodetectProperties(false);
	}

	public boolean isPKEmpty() {
		return getConferenceID() == 0;
	}

	public Conference() {
		createDate = org.alt60m.util.DateUtils.clearTimeFromDate(new Date());
	}

	public int getConferenceID() { return conferenceID; }
	public void setConferenceID(int conferenceID) { this.conferenceID = conferenceID; }

	public Date getCreateDate(){ return createDate; }
	public void setCreateDate(Date createDate){ this.createDate = org.alt60m.util.DateUtils.clearTimeFromDate(createDate); }

	public String getName() { return this.name; }
	public void setName(String name) { this.name=name; }

	public String getTheme() { return this.theme; }
	public void setTheme(String theme) { this.theme=theme; }
	
	public String getPassword() { return this.password; }
	public void setPassword(String password) { this.password=password; }
	
	public String getStaffPassword() { return this.staffPassword; }
	public void setStaffPassword(String staffPassword) { this.staffPassword=staffPassword; }
	
	public String getRegion() { return this.region; }
	public void setRegion(String region) { this.region=region; }

	public String getBriefDescription() { return this.briefDescription; }
	public void setBriefDescription(String briefDescription) { this.briefDescription=briefDescription; }

	public String getContactName() { return this.contactName; }
	public void setContactName(String contactName) { this.contactName=contactName; }
	
	public String getContactEmail() { return this.contactEmail; }
	public void setContactEmail(String contactEmail) { this.contactEmail=contactEmail; }
	
	public String getContactPhone() { return this.contactPhone; }
	public void setContactPhone(String contactPhone) { this.contactPhone=contactPhone; }
	
	public String getContactAddress1() { return this.contactAddress1; }
	public void setContactAddress1(String contactAddress1) { this.contactAddress1=contactAddress1; }
	
	public String getContactAddress2() { return this.contactAddress2; }
	public void setContactAddress2(String contactAddress2) { this.contactAddress2=contactAddress2; }
	
	public String getContactCity() { return this.contactCity; }
	public void setContactCity(String contactCity) { this.contactCity=contactCity; }
	
	public String getContactState() { return this.contactState; }
	public void setContactState(String contactState) { this.contactState=contactState; }
	
	public String getContactZip() { return this.contactZip; }
	public void setContactZip(String contactZip) { this.contactZip=contactZip; }
	
	public String getSplashPageURL() { return this.splashPageURL; }
	public void setSplashPageURL(String splashPageURL) { this.splashPageURL=splashPageURL; }
	
	public String getConfirmationEmail(){ return confirmationEmail; }
	public void setConfirmationEmail(String confirmationEmail){ this.confirmationEmail = confirmationEmail; }

	public boolean getAcceptVisa(){ return acceptVisa != null && acceptVisa.equals("T"); }
	public void setAcceptVisa(boolean acceptVisa){ this.acceptVisa = acceptVisa ? "T" : "F"; }

	public String getAcceptVisaString(){ return acceptVisa; }
	public void setAcceptVisaString(String acceptVisa){ this.acceptVisa = acceptVisa; }

	public boolean getAcceptMasterCard(){ return acceptMasterCard != null && acceptMasterCard.equals("T"); }
	public void setAcceptMasterCard(boolean acceptMasterCard){ this.acceptMasterCard = acceptMasterCard ? "T" : "F"; }

	public String getAcceptMasterCardString(){ return acceptMasterCard; }
	public void setAcceptMasterCardString(String acceptMasterCard){ this.acceptMasterCard = acceptMasterCard; }

	public boolean getAcceptAmericanExpress(){ return acceptAmericanExpress != null && acceptAmericanExpress.equals("T"); }
	public void setAcceptAmericanExpress(boolean acceptAmericanExpress){ this.acceptAmericanExpress = acceptAmericanExpress ? "T" : "F"; }

	public String getAcceptAmericanExpressString(){ return acceptAmericanExpress; }
	public void setAcceptAmericanExpressString(String acceptAmericanExpress){ this.acceptAmericanExpress = acceptAmericanExpress; }

	public boolean getAcceptDiscover(){ return acceptDiscover != null && acceptDiscover.equals("T"); }
	public void setAcceptDiscover(boolean acceptDiscover){ this.acceptDiscover = acceptDiscover ? "T" : "F"; }

	public String getAcceptDiscoverString(){ return acceptDiscover; }
	public void setAcceptDiscoverString(String acceptDiscover){ this.acceptDiscover = acceptDiscover; }

	public boolean getAcceptEChecks(){ return acceptEChecks != null && acceptEChecks.equals("T"); }
	public void setAcceptEChecks(boolean acceptEChecks){ this.acceptEChecks = acceptEChecks ? "T" : "F"; }

	public String getAcceptEChecksString(){ return acceptEChecks; }
	public void setAcceptEChecksString(String acceptEChecks){ this.acceptEChecks = acceptEChecks; }

	public boolean getAcceptScholarships(){ return acceptScholarships != null && acceptScholarships.equals("T"); }
	public void setAcceptScholarships(boolean acceptScholarships){ this.acceptScholarships = acceptScholarships ? "T" : "F"; }

	public String getAcceptScholarshipsString(){ return acceptScholarships; }
	public void setAcceptScholarshipsString(String acceptScholarships){ this.acceptScholarships = acceptScholarships; }

	public String getAuthnetPassword(){ return authnetPassword; }
	public void setAuthnetPassword(String authnetPassword){ this.authnetPassword = authnetPassword; }

	public Date getPreRegStart(){ return preRegStart; }
	public void setPreRegStart(Date preRegStart){ this.preRegStart = org.alt60m.util.DateUtils.clearTimeFromDate(preRegStart); }

	public Date getPreRegEnd(){ return preRegEnd; }
	public void setPreRegEnd(Date preRegEnd){ this.preRegEnd = org.alt60m.util.DateUtils.clearTimeFromDate(preRegEnd); }

	public Date getDefaultDateStaffArrive(){ return defaultDateStaffArrive; }
	public void setDefaultDateStaffArrive(Date defaultDateStaffArrive){ this.defaultDateStaffArrive = org.alt60m.util.DateUtils.clearTimeFromDate(defaultDateStaffArrive); }

	public Date getDefaultDateStaffLeave(){ return defaultDateStaffLeave; }
	public void setDefaultDateStaffLeave(Date defaultDateStaffLeave){ this.defaultDateStaffLeave = org.alt60m.util.DateUtils.clearTimeFromDate(defaultDateStaffLeave); }

	public Date getDefaultDateGuestArrive(){ return defaultDateGuestArrive; }
	public void setDefaultDateGuestArrive(Date defaultDateGuestArrive){ this.defaultDateGuestArrive = org.alt60m.util.DateUtils.clearTimeFromDate(defaultDateGuestArrive); }

	public Date getDefaultDateGuestLeave(){ return defaultDateGuestLeave; }
	public void setDefaultDateGuestLeave(Date defaultDateGuestLeave){ this.defaultDateGuestLeave = org.alt60m.util.DateUtils.clearTimeFromDate(defaultDateGuestLeave); }

	public float getOnsiteCost(){ return onsiteCost; }
	public void setOnsiteCost(float onsiteCost){ this.onsiteCost = onsiteCost; }

	public float getCommuterCost(){ return commuterCost; }
	public void setCommuterCost(float commuterCost){ this.commuterCost = commuterCost; }

	public float getPreRegDeposit(){ return preRegDeposit; }
	public void setPreRegDeposit(float preRegDeposit){ this.preRegDeposit = preRegDeposit; }

	public float getDiscountFullPayment(){ return discountFullPayment; }
	public void setDiscountFullPayment(float discountFullPayment){ this.discountFullPayment = discountFullPayment; }

	public float getDiscountEarlyReg(){ return discountEarlyReg; }
	public void setDiscountEarlyReg(float discountEarlyReg){ this.discountEarlyReg = discountEarlyReg; }

	public Date getDiscountEarlyRegDate(){ return discountEarlyRegDate; }
	public void setDiscountEarlyRegDate(Date discountEarlyRegDate){ this.discountEarlyRegDate = org.alt60m.util.DateUtils.clearTimeFromDate(discountEarlyRegDate); }

	public String getCheckPayableTo() { return this.checkPayableTo; }
	public void setCheckPayableTo(String checkPayableTo) { this.checkPayableTo=checkPayableTo; }

	public String getMerchantAcctNum() { return this.merchantAcctNum; }
	public void setMerchantAcctNum(String merchantAcctNum) { this.merchantAcctNum=merchantAcctNum; }

	public String getConfImageID() { return this.confImageID; }
	public void setConfImageID(String confImageID) { this.confImageID=confImageID; }
	
	public String getFontFace() { return this.fontFace; }
	public void setFontFace(String fontFace) { this.fontFace=fontFace; }
	
	public String getBackgroundColor() { return this.backgroundColor; }
	public void setBackgroundColor(String backgroundColor) { this.backgroundColor=backgroundColor; }
	
	public String getForegroundColor() { return this.foregroundColor; }
	public void setForegroundColor(String foregroundColor) { this.foregroundColor=foregroundColor; }
	
	public String getHighlightColor() { return this.highlightColor; }
	public void setHighlightColor(String highlightColor) { this.highlightColor=highlightColor; }

	public String getBackgroundColor2() { return this.backgroundColor2; }
	public void setBackgroundColor2(String backgroundColor2) { this.backgroundColor2=backgroundColor2; }
	
	public String getBackgroundColor3() { return this.backgroundColor3; }
	public void setBackgroundColor3(String backgroundColor3) { this.backgroundColor3=backgroundColor3; }
	
	public String getHighlightColor2() { return this.highlightColor2; }
	public void setHighlightColor2(String highlightColor2) { this.highlightColor2=highlightColor2; }

	public String getRequiredColor() { return this.requiredColor; }
	public void setRequiredColor(String requiredColor) { this.requiredColor=requiredColor; }

// Associations

	public Vector getRegistrations(){
		Registration r = new Registration();
		r.setConferenceID(conferenceID);
		return r.selectList();
	}
	public Vector getRegistrations(String orderField, boolean DESC) {
		Registration r = new Registration();
		return r.selectList("fk_ConferenceID = '" + conferenceID + "' ORDER BY " + orderField + " " + (DESC ? "DESC" : "ASC"));
	}
	public void assocRegistration(Registration r) {
		r.setConferenceID(conferenceID);
		r.update();
	}
	public void dissocRegistration(Registration r) {
		r.setConferenceID(0);
		r.update();
	}

	public Vector getQuestions(){
		Question q = new Question();
		q.setConferenceID(conferenceID);
		return q.selectList();
	}
	public Vector getQuestions(String orderField, boolean DESC) {
		Question q = new Question();
		return q.selectList("fk_ConferenceID = '" + conferenceID + "' ORDER BY " + orderField + " " + (DESC ? "DESC" : "ASC"));
	}
	public void assocQuestion(Question q) {
		q.setConferenceID(conferenceID);
		q.update();
	}
	public void dissocQuestion(Question q) {
		q.setConferenceID(0);
		q.update();
	}

	public Vector getCustomItems(){
		CustomItem ci = new CustomItem();
		ci.setConferenceID(conferenceID);
		return ci.selectList();
	}
	public Vector getCustomItems(String orderField, boolean DESC) {
		CustomItem ci = new CustomItem();
		return ci.selectList("fk_ConferenceID = '" + conferenceID + "' ORDER BY " + orderField + " " + (DESC ? "DESC" : "ASC"));
	}
	public void assocCustomItem(CustomItem ci) {
		ci.setConferenceID(conferenceID);
		ci.update();
	}
	public void dissocCustomItem(CustomItem ci) {
		ci.setConferenceID(0);
		ci.update();
	}

	public Vector getMerchandise(){
		Merchandise m = new Merchandise();
		m.setConferenceID(conferenceID);
		return m.selectList();
	}
	public Vector getMerchandise(String orderField, boolean DESC) {
		Merchandise m = new Merchandise();
		return m.selectList("fk_ConferenceID = '" + conferenceID + "' ORDER BY " + orderField + " " + (DESC ? "DESC" : "ASC"));
	}
	public void assocMerchandise(Merchandise m) {
		m.setConferenceID(conferenceID);
		m.update();
	}
	public void dissocMerchandise(Merchandise m) {
		m.setConferenceID(0);
		m.update();
	}

// For migration

	private String acceptCreditCards = "";
	public boolean getAcceptCreditCards(){ return acceptCreditCards != null && acceptCreditCards.equals("T"); }
	public void setAcceptCreditCards(boolean acceptCreditCards){ this.acceptCreditCards = acceptCreditCards ? "T" : "F"; }
	public String getAcceptCreditCardsString(){ return acceptCreditCards; }
	public void setAcceptCreditCardsString(String acceptCreditCards){ this.acceptCreditCards = acceptCreditCards; }

//	private Vector customMigrate = new Vector();
//	public Vector getCustomMigrate(){ return customMigrate; }
//	public void setCustomMigrate(Vector options){
//		customMigrate = options;
//	}
}
