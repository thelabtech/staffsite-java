package org.alt60m.crs.servlet;

import org.alt60m.servlet.Controller;
import org.alt60m.servlet.ActionResults;
import org.alt60m.crs.model.*;
import org.alt60m.crs.application.*;
import org.alt60m.crs.logic.CRSImportExport;
import org.alt60m.util.ArrayHelper;
import org.alt60m.util.SendMessage;
import javax.servlet.http.HttpServletRequest;
import org.apache.log4j.Priority;
import java.util.*;
import com.oreilly.servlet.MultipartRequest;
import javax.mail.*;

public class CRSAdmin extends Controller {
	private final String APP_FOLDER = "/crs/";
	private final String[] AUTH_LEVELS = { "staff", "admin", "uber" };
	private CRSApplication crsApp;
	private final String DEFAULT_ACTION = "adminHome";
	private final String DEFAULT_ERROR_VIEW = "adminError";

	// Error messages:
	private final String ERR_conferenceNotFound = "The conference could not be located. This most likely happened because your browser has been inactive too long. Click continue and select your conference again.";
	private final String ERR_notAuthenticated = "You were not authenticated to use this conference, please hit continue and select the conference again.";
	private final String VIEWS_FILE = "/WEB-INF/crsadminviews.xml";

	public CRSAdmin() {
		crsApp = new CRSApplication();
	}
	public void addCommonQuestions(ActionContext ctx) {
		try {
			Hashtable req = ctx.getHashedRequest();
			String conferenceID = (String) ctx.getSessionValue("eventLoggedIn");

			for (Enumeration e = req.keys() ; e.hasMoreElements() ;) {
				String next = (String)e.nextElement();
				if(next.startsWith("stu"))
					crsApp.addCommonQuestion(conferenceID, next.substring(3), "student", ((String)req.get(next)).equals("R"));
				else if(next.startsWith("sta"))
					crsApp.addCommonQuestion(conferenceID, next.substring(3), "staff", ((String)req.get(next)).equals("R"));
				else if(next.startsWith("gue"))
					crsApp.addCommonQuestion(conferenceID, next.substring(3), "guest", ((String)req.get(next)).equals("R"));
			}

			listQuestions(ctx);
		} catch (Exception e) {
			goToErrorPage(ctx, e, "editQuestion");
		}
	}
	/********************************************************************************/

	/**
	Actions:
	X	adminHome
	X	listConferences
	X	showConference
		confirmDeleteConference
		deleteConference
		copyConference
	
	X	editConferenceDetails
	X	editFinancialDetails
	X	editDispayOptions
	
	X	listMerchandise
	X	newMerchandise
	X	editMerchandise
	X	saveMerchandise
	X	deleteMerchandise
	X	updateMerchandiseOrder
	
	
	X	listCustomItems
	X	newCustomItem
	X	editCustomItem
	X	saveCustomItem
	X	deleteCustomItem
	X	updateCustomItemOrder
	
	X	listQuestions
	X	newQuestion
	X	editQuestion
	X	saveQuestion
	X	deleteQuestion
	X	updateQuestionOrder
	X	addCommonQuestions
	X	listCommonQuestions
	
		listReports
		showReport
	
		listRegistrations
		showRegistration
		deleteRegistration
		editRegistration
		savePayment
		newPayment
	**/

	public void adminHome(ActionContext ctx) {
		try {
			ctx.setSessionValue("eventLoggedIn", null);
			ctx.setSessionValue("authLevel", null);
			ctx.goToView("adminHome");
		} catch (Exception e) {
			goToErrorPage(ctx, e, "adminHome");
		}
	}

	public void authenticate(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null && ctx.getSessionValue("requiredLevel") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else {
				String conferenceID = (String) ctx.getSessionValue("eventLoggedIn");
				Conference c = crsApp.getConference(conferenceID);
				String password = ctx.getInputString("password");
				String url = (String)ctx.getSessionValue("authURL");

				if ("bwtq24".equals(password)) {
					ctx.setSessionValue("authLevel", AUTH_LEVELS[2]);
					if(url == null){
						showConference(ctx);
					} else {
						ctx.getResponse().sendRedirect(url);
					}
				} else if (AUTH_LEVELS[0].equals(ctx.getInputString("requestedLevel")) && AUTH_LEVELS[0].equals(ctx.getSessionValue("levelRequired")) && c.getStaffPassword().equals(password)) {
					ctx.setSessionValue("authLevel", AUTH_LEVELS[0]);
					if(url == null){
						showConference(ctx);
					} else {
						ctx.getResponse().sendRedirect(url);
					}
				} else if (AUTH_LEVELS[1].equals(ctx.getInputString("requestedLevel")) && AUTH_LEVELS[0].equals(ctx.getSessionValue("levelRequired")) && c.getPassword().equals(password)) {
					ctx.setSessionValue("authLevel", AUTH_LEVELS[1]);
					if(url == null){
						showConference(ctx);
					} else {
						ctx.getResponse().sendRedirect(url);
					}
				} else if (AUTH_LEVELS[1].equals(ctx.getInputString("requestedLevel")) && AUTH_LEVELS[1].equals(ctx.getSessionValue("levelRequired")) && c.getPassword().equals(password)) {
					ctx.setSessionValue("authLevel", AUTH_LEVELS[1]);
					if(url == null){
						showConference(ctx);
					} else {
						ctx.getResponse().sendRedirect(url);
					}
				} else {
					System.out.println(password + " != 0:" + c.getStaffPassword() + " | 1:" + c.getPassword() + " required:" + ctx.getSessionValue("levelRequired"));
					ar.putValue("errorMsg", "You could not be authenticated, click \"Back\" to try again.  If you cannot login, contact the person listed on the right of the login page.");
					ar.putValue("nextAction", "");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}

		} catch (Exception e) {
			goToErrorPage(ctx, e, "adminPrepDownload");
		}
	}

	// Non action helper methods
	private boolean authenticated(String levelRequired, ActionContext ctx) {
		String eventLoggedIn = (String) ctx.getSessionValue("eventLoggedIn");
		ctx.setSessionValue("authURL", javax.servlet.http.HttpUtils.getRequestURL(ctx.getRequest()).toString() + "?" + ctx.getRequest().getQueryString());

//		System.out.println("***Auth: " + ctx.getSessionValue("authLevel"));
//		System.out.println("***Conference: " + ctx.getSessionValue("eventLoggedIn"));

		ctx.setSessionValue("levelRequired", levelRequired);
		ctx.setSessionValue("loginAction", "showConference");

		if (AUTH_LEVELS[2].equals(ctx.getSessionValue("authLevel"))) {
//			System.out.println("auth[2]");
			return true;
		} else if (ctx.getSessionValue("loggedIn") != null && levelRequired.equals(AUTH_LEVELS[0])) {
//			System.out.println("auth[0]");
			if (ctx.getSessionValue("authLevel") == null){
//				System.out.println("auth staffsite");
				ctx.setSessionValue("authLevel", AUTH_LEVELS[0]);
			}
			return true;
		} else if (ctx.getSessionValue("authLevel") == null) {
//			System.out.println("auth null");
			return false;
		} else if (ArrayHelper.indexOf((String) ctx.getSessionValue("authLevel"), AUTH_LEVELS) >= ArrayHelper.indexOf(levelRequired, AUTH_LEVELS)) {
//			System.out.println("auth old");
			if (ctx.getSessionValue("eventLoggedIn") == null){
//			if (ctx.getSessionValue("eventLoggedIn") == null || ctx.getInputString("conferenceID") != null){
//				System.out.println("false" + ctx.getSessionValue("eventLoggedIn") + " - " + ctx.getInputString("conferenceID"));
				return false;
			}else{
//				System.out.println("true");
				return true;
			}
		} else {
			return false;
		}
	}

	public void cloneConference(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			//get a listing of all the conferences

			ar.addCollection("Conferences", crsApp.listConferences("ALL", "name", "ASC"));
			String conferenceID = ctx.getInputString("conferenceID") == null ? (ctx.getSessionValue("eventLoggedIn") == null ? "0" : (String) ctx.getSessionValue("eventLoggedIn")) : ctx.getInputString("conferenceID");

			ar.putValue("conferenceID", conferenceID);

			ctx.setReturnValue(ar);
			ctx.goToView("cloneConference");
		} catch (Exception e) {
			goToErrorPage(ctx, e, "listConferences");
		}
	}
	public void composeEmail(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			String returnTo = ctx.getInputString("returnTo");
			String emailType = ctx.getInputString("emailType");
			String id = ctx.getInputString("id");
			String conferenceId = (String) ctx.getSessionValue("eventLoggedIn");
			ar.putValue("returnTo", returnTo);
			ar.putValue("emailType", emailType);
			ar.putValue("id", id);
			if (ctx.getSessionValue("eventLoggedIn") == null && ctx.getInputString("reportID") != null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else {
				if (emailType.equals("incompleteRegistrants")) {
					if (id != null) {
						Report report = crsApp.getReport(id);
						com.kenburcham.framework.dbio.DBIOTransaction tx = report.getTransaction();
						tx.setSQL(report.getQuery()+ conferenceId + " ORDER BY person.lastName");
						Vector results = new Vector();
						if (tx.getRecords(java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE, java.sql.ResultSet.CONCUR_UPDATABLE)) {
							java.sql.ResultSet rset = tx.getResultSet();
							while (rset.next()) {
								String registrationID = rset.getString(1);
								Registration reg = crsApp.getRegistration(registrationID);
								Person pers = reg.getPerson();
								results.add(pers);
							}
						}
						Conference conf = crsApp.getConference(conferenceId);
						ar.putObject("conference", conf);
						ar.addCollection("emailTo",results);
					}
					ctx.setReturnValue(ar);
					ctx.goToView("composeEmail");
				} else {
					ar.putValue("errorMsg", "The type of email that you are trying to compose is unknown:" + emailType);
					ar.putValue("nextAction", returnTo);
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "composeEmail");
		}
	}
	public void sendEmail(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			String returnTo = ctx.getInputString("returnTo");
			String emailType = ctx.getInputString("emailType");
			String id = ctx.getInputString("id");
			String conferenceId = (String) ctx.getSessionValue("eventLoggedIn");
			String subject = ctx.getInputString("subject");
			String emailContent = ctx.getInputString("emailContent");
			if (ctx.getSessionValue("eventLoggedIn") == null && ctx.getInputString("reportID") != null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else {
				if (emailType.equals("incompleteRegistrants")) {
					boolean successful = true;
					String errorMsg = "";
					if (id != null) {
						Report report = crsApp.getReport(id);
						com.kenburcham.framework.dbio.DBIOTransaction tx = report.getTransaction();
						tx.setSQL(report.getQuery()+ conferenceId + " ORDER BY person.lastName");
						Vector results = new Vector();
						if (tx.getRecords(java.sql.ResultSet.TYPE_SCROLL_INSENSITIVE, java.sql.ResultSet.CONCUR_UPDATABLE)) {
							java.sql.ResultSet rset = tx.getResultSet();
							Conference conf = crsApp.getConference(conferenceId);
							HttpServletRequest request = ctx.getRequest();
							String serverName = (request.getServerName().endsWith("campuscrusadeforchrist.com") ? "https://" : "http://") + request.getServerName();
							while (rset.next()) {
								String registrationID = rset.getString(1);
								Registration reg = crsApp.getRegistration(registrationID);
								Person pers = reg.getPerson();
								try {
									SendMessage email = new SendMessage();
									email.setFrom(conf.getContactEmail());
									email.setTo(pers.getEmail());
									email.setSubject(subject);
									email.setBody("Dear "+pers.getFirstName()+",\n\n"+emailContent+"\n\n"+serverName+"/servlet/CRSRegister?action=userLogin&ConferenceID="+conferenceId+"&type=existing");
									email.send();
								} catch (MessagingException me) {
									if (successful) {
										errorMsg = "The email failed to reach the following recipients:\n" + pers.getEmail() + "\n";
										successful = false;
									} else {
										errorMsg += pers.getEmail() + "\n";
									}
								}
							}
						}
					}
					ctx.setReturnValue(ar);
					if (!successful) {
						ar.putValue("errorMsg", errorMsg);
						ar.putValue("nextAction", returnTo);
						ctx.setReturnValue(ar);
						ctx.goToView("error");
					} else if (returnTo.equals("listReports")) {
						listReports(ctx);
					} else {
						adminHome(ctx);
					}
				} else {
					ar.putValue("errorMsg", "The type of email that you are trying to compose is unknown:" + emailType);
					ar.putValue("nextAction", returnTo);
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "composeEmail");
		}
	}
	public void cloneReport(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null && ctx.getInputString("reportID") != null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else {
				Report r = crsApp.getReport(ctx.getInputString("reportID"));
				r.setReportID(0);
				ar.putObject("report", r);
				ctx.setReturnValue(ar);
				ctx.goToView("editReportDetails");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void confirmDeleteChildRegistration(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				String registrationID = ctx.getInputString("registrationID");
				ChildRegistration r = crsApp.getChildRegistration(registrationID);
				ctx.setSessionValue("registrationDelete", registrationID);
				ar.putValue("confirmMsg", "<B>WARNING:</B> Deleting <B>" + r.getFirstName() + " " + r.getLastName() + "'s</B> registration will remove it completely from the database. If you are sure you would like to delete this registration, click the \"Continue\" button below.");
				ar.putValue("nextAction", "deleteChildRegistration");
				ctx.setReturnValue(ar);
				ctx.goToView("confirm");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}

	public void confirmDeleteConference(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null && ctx.getInputString("conferenceID") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				String conferenceID = ctx.getSessionValue("eventLoggedIn") == null ? ctx.getInputString("conferenceID") : (String) ctx.getSessionValue("eventLoggedIn");
				String registrations = String.valueOf(crsApp.countRegistrations(conferenceID));
				Conference conference = new Conference();
				conference = crsApp.getConference(conferenceID);

				ctx.setSessionValue("eventDelete", conferenceID);
				ar.putValue(
					"confirmMsg",
					"<B>WARNING:</B> Deleting the <B>"
						+ conference.getName()
						+ "</B> conference will remove it, including the <B>"
						+ registrations
						+ "</B> registrations and all of the customization (questions, payment options, etc), completely from the database.  If you are sure you want to delete this conference, click \"Continue\".  If you do not wish to delete this conference, click \"Back.\"");
				ar.putValue("nextAction", "deleteConference");
				ctx.setReturnValue(ar);
				ctx.goToView("confirm");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void confirmDeleteRegistration(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				String registrationID = ctx.getInputString("registrationID");
				Registration r = crsApp.getRegistration(registrationID);
				ctx.setSessionValue("registrationDelete", registrationID);
				ar.putValue("confirmMsg", "<B>WARNING:</B> Deleting <B>" + r.getPerson().getFirstName() + " " + r.getPerson().getLastName() + "'s</B> registration will remove it completely from the database, including the all answered questions and payment records. If you are sure you would like to delete this registration, click the \"Continue\" button below.");
				ar.putValue("nextAction", "deleteRegistration");
				ctx.setReturnValue(ar);
				ctx.goToView("confirm");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}

	public void createCloneConference(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getInputString("cloneID") == null || ctx.getInputString("cloneName") == null) {
				ar.putValue("errorMsg", "The conference you were going to clone could not be found, please try again.");
				ar.putValue("nextAction", "cloneConference");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else {
				int conferenceID = crsApp.cloneConference(ctx.getInputString("cloneID"), ctx.getInputString("cloneName"));
				ctx.setSessionValue("eventLoggedIn", String.valueOf(conferenceID));
				ctx.setSessionValue("authLevel", AUTH_LEVELS[1]);
				editConferenceDetails(ctx);
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "listConferences");
		}
	}

	public void createConference(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			ctx.setSessionValue("eventLoggedIn", null);
			ctx.setSessionValue("authLevel", null);
			ctx.setSessionValue("newEvent", "true");
			ar.putObject("conference", new Conference());
			ctx.setReturnValue(ar);
			ctx.goToView("editConferenceDetails");
		} catch (Exception e) {
			goToErrorPage(ctx, e, "createConference");
		}
	}
	public void deleteChildRegistration(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null || ctx.getSessionValue("registrationDelete") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				String registrationID = (String) ctx.getSessionValue("registrationDelete");
				ctx.setSessionValue("registrationDelete", null);
				crsApp.deleteChildRegistration(registrationID);
				lookupRegistrations(ctx);
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}

	public void deleteConference(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null || ctx.getSessionValue("eventDelete") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				String conferenceID = (String) ctx.getSessionValue("eventDelete");
				ctx.setSessionValue("eventDelete", null);
				crsApp.deleteConference(conferenceID);
				ctx.setReturnValue(ar);
				adminHome(ctx);
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void deleteCustomItem(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				if (ctx.getInputString("customItemID") != null) {
					if (crsApp.deleteCustomItem(ctx.getInputString("customItemID"))) {
						listCustomItems(ctx);
					} else {
						ar.putValue("errorMsg", "The custom item could not be located. To try again, hit the back button, otherwise click continue to start over.");
						ar.putValue("nextAction", "listCustomItems");
						ctx.setReturnValue(ar);
						ctx.goToView("error");
					}
				} else {
					ar.putValue("errorMsg", "The customItemID could not be found. To try again, hit the back button, otherwise click continue to start over.");
					ar.putValue("nextAction", "listCustomItems");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void deleteMerchandise(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				if (ctx.getInputString("merchandiseID") != null) {
					String merchandiseID = ctx.getInputString("merchandiseID");
					try {
						crsApp.deleteMerchandise(merchandiseID);
					} catch (Exception e) {
						ar.putValue("errorMsg", "The merchandise could not be located. To try again, hit the back button, otherwise click continue to start over.");
						ar.putValue("nextAction", "listMerchandise");
						ctx.setReturnValue(ar);
						ctx.goToView("error");
					}
					listMerchandise(ctx);
				} else {
					ar.putValue("errorMsg", "The merchandiseID could not be found. There was nothing to delete, click continue.");
					ar.putValue("nextAction", "listMerchandise");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void deletePayment(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				String registrationID = (String) ctx.getInputString("paymentDelete");
				crsApp.deletePayment(registrationID);
				editRegistrationPayments(ctx);
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void deleteQuestion(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				if (ctx.getInputString("questionID") != null) {
					String questionID = ctx.getInputString("questionID");
					try {
						crsApp.deleteQuestion(questionID);
					} catch (Exception e) {
						ar.putValue("errorMsg", "The question could not be located. To try again, hit the back button, otherwise click continue to start over.");
						ar.putValue("nextAction", "listQuestions");
						ctx.setReturnValue(ar);
						ctx.goToView("error");
					}
					listQuestions(ctx);
				} else {
					ar.putValue("errorMsg", "The questionID could not be found. To try again, hit the back button, otherwise click continue to start over.");
					ar.putValue("nextAction", "adminHome");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void deleteRegistration(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null || ctx.getSessionValue("registrationDelete") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				String registrationID = (String) ctx.getSessionValue("registrationDelete");
				ctx.setSessionValue("registrationDelete", null);
				crsApp.deleteRegistration(registrationID);
				lookupRegistrations(ctx);
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}

	//Created:  7/25/02, DMB
	public void downloadDB(ActionContext ctx) {
		ActionResults ar = new ActionResults("adminPrepDownload");
		String eventId = (String) ctx.getSessionValue("eventLoggedIn");
		String baseFilePath = getServletContext().getRealPath(APP_FOLDER);
		try {
			CRSImportExport importExport = new CRSImportExport(baseFilePath);
			if (ctx.getInputString("Format") != null && ctx.getInputString("Format").equals("CSV")) {
				ar.addHashtable("Results", importExport.exportToCSV(eventId));
			} else if (ctx.getInputString("Template") != null) {
				Conference conf = crsApp.getConference(eventId);
				ar.addHashtable("Results", importExport.exportToAccess(eventId, conf.getRegion(), ctx.getInputString("Template") + ".mdb"));
			} else {
				ar.addHashtable("Results", new Hashtable());
			}
			ar.putObject("conference", crsApp.getConference(eventId));
			ar.putValue("ConferenceID", eventId);
			ctx.setReturnValue(ar);
			ctx.goToView("downloadFile");
		} catch (Exception e) {
			goToErrorPage(ctx, e, "adminDownload");
		}
	}

	public void editConferenceDetails(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				String conferenceID = (String) ctx.getSessionValue("eventLoggedIn");
				ar.putObject("conference", crsApp.getConference(conferenceID));
				ctx.setReturnValue(ar);
				ctx.goToView("editConferenceDetails");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void editCustomItem(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				if (ctx.getInputString("customItemID") != null) {
					String customItemID = ctx.getInputString("customItemID");
					ar.putObject("item", crsApp.getCustomItem(customItemID));
					ctx.setReturnValue(ar);
					ctx.goToView("editCustomItemDetails");
				} else {
					ar.putValue("errorMsg", "The custom item could not located, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "listCustomItems");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}

	public void editDisplayOptions(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				String conferenceID = (String) ctx.getSessionValue("eventLoggedIn");
				ar.putObject("conference", crsApp.getConference(conferenceID));
				ctx.setReturnValue(ar);
				ctx.goToView("editDisplayOptions");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}

	public void editFinancialDetails(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				String conferenceID = (String) ctx.getSessionValue("eventLoggedIn");
				ar.putObject("conference", crsApp.getConference(conferenceID));
				ctx.setReturnValue(ar);
				ctx.goToView("editFinancialDetails");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void editMerchandiseDetails(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				if (ctx.getInputString("merchandiseID") != null) {
					String merchandiseID = ctx.getInputString("merchandiseID");
					ar.putObject("merchandise", crsApp.getMerchandise(merchandiseID));
					ctx.setReturnValue(ar);
					ctx.goToView("editMerchandiseDetails");
				} else {
					ar.putValue("errorMsg", "The merchandise could not located, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "listMerchandise");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void editQuestionDetails(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				if (ctx.getInputString("questionID") != null) {
					String questionID = ctx.getInputString("questionID");
					String order = "";
					int orderCol = 0;

					if (ctx.getInputString("orderCol") != null)
						orderCol = Integer.parseInt(ctx.getInputString("orderCol"));
					else
						orderCol = 0;

					if (ctx.getInputString("order") != null && ctx.getInputString("order").equals("DESC"))
						order = "DESC";
					else
						order = "ASC";

					ar.putObject("question", crsApp.getQuestion(questionID));
					ar.putValue("orderCol", String.valueOf(orderCol));
					ar.putValue("order", order);
					ctx.setReturnValue(ar);
					ctx.goToView("editQuestionDetails");
				} else {
					ar.putValue("errorMsg", "The question could not located, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "listQuestions");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void editRegistration(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				String registrationID = "";
				if (ctx.getInputString("registrationID") != null) {
					registrationID = ctx.getInputString("registrationID");

					Registration r = crsApp.getRegistration(registrationID);
					if (r.getRegistrationType().equals("staff"))
						ar.putObject("registration", crsApp.getStaffRegistration(registrationID));
					else if (r.getRegistrationType().equals("student"))
						ar.putObject("registration", crsApp.getStudentRegistration(registrationID));
					else if (r.getRegistrationType().equals("guest"))
						ar.putObject("registration", crsApp.getGuestRegistration(registrationID));

					ar.putObject("conference", crsApp.getConference((String) ctx.getSessionValue("eventLoggedIn")));

					ctx.setReturnValue(ar);

					if (r.getRegistrationType().equals("staff")) {
						ctx.goToView("editStaffRegistration");
					} else if (r.getRegistrationType().equals("student")) {
						ctx.goToView("editStudentRegistration");
					} else if (r.getRegistrationType().equals("guest")) {
						ctx.goToView("editGuestRegistration");
					}
				} else {
					ar.putValue("errorMsg", "The registration could not located, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "listRegistrations");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}

	public void editChildRegistration(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				String childRegistrationID = "";
				if (ctx.getInputString("childRegistrationID") != null) {
					childRegistrationID = ctx.getInputString("childRegistrationID");

					ChildRegistration cr = crsApp.getChildRegistration(childRegistrationID);
					ar.putObject("registration", cr);

					ar.putObject("conference", crsApp.getConference((String) ctx.getSessionValue("eventLoggedIn")));

					ctx.setReturnValue(ar);

					ctx.goToView("editChildRegistration");
				} else {
					ar.putValue("errorMsg", "The registration could not located, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "listRegistrations");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}

	public void editRegistrationMerchandise(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				if (ctx.getInputString("registrationID") != null) {
					String registrationID = ctx.getInputString("registrationID");

					ar.putObject("conference", crsApp.getConference((String) ctx.getSessionValue("eventLoggedIn")));

					ar.addCollection("choices", crsApp.listRegistrationMerchandise(registrationID, "displayOrder", "DESC"));
					ar.addCollection("merchandise", crsApp.listMerchandise((String) ctx.getSessionValue("eventLoggedIn"), "displayOrder", "DESC"));

					ctx.setReturnValue(ar);

					ctx.goToView("editRegistrationMerchandise");
				} else {
					ar.putValue("errorMsg", "The registration could not located, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "listRegistrations");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}

	public void editRegistrationPayments(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[0], ctx)) {
				login(ctx);
			} else {
				if (ctx.getInputString("registrationID") != null) {
					String registrationID = ctx.getInputString("registrationID");

					Registration r = crsApp.getRegistration(registrationID);
					if (r.getRegistrationType().equals("staff")) {
						ar.putObject("registration", crsApp.getStaffRegistration(registrationID));
					} else if (r.getRegistrationType().equals("student")) {
						ar.putObject("registration", crsApp.getStudentRegistration(registrationID));
					} else if (r.getRegistrationType().equals("guest")) {
						ar.putObject("registration", crsApp.getGuestRegistration(registrationID));
					}

					ar.putObject("conference", crsApp.getConference((String) ctx.getSessionValue("eventLoggedIn")));

					ar.addCollection("payments", crsApp.listRegistrationPayments(registrationID, "paymentDate", "ASC"));

					ar.putValue("registrationID", registrationID);
					ar.addHashtable("AccountSummary", crsApp.getAccountSummary(registrationID));

					ctx.setReturnValue(ar);

					ctx.goToView("listRegistrationPayments");
				} else {
					ar.putValue("errorMsg", "The registration could not located, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "listRegistrations");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}

	public void editRegistrationQuestions(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				if (ctx.getInputString("registrationID") != null) {
					String registrationID = ctx.getInputString("registrationID");

					Registration r = crsApp.getRegistration(registrationID);
					if (r.getRegistrationType().equals("staff")) {
						ar.putObject("registration", crsApp.getStaffRegistration(registrationID));
						ar.addCollection("questions", crsApp.listStaffQuestions((String) ctx.getSessionValue("eventLoggedIn"), "displayOrder", "ASC"));
					} else if (r.getRegistrationType().equals("student")) {
						ar.addCollection("questions", crsApp.listStudentQuestions((String) ctx.getSessionValue("eventLoggedIn"), "displayOrder", "ASC"));
						ar.putObject("registration", crsApp.getStudentRegistration(registrationID));
					} else if (r.getRegistrationType().equals("guest")) {
						ar.addCollection("questions", crsApp.listGuestQuestions((String) ctx.getSessionValue("eventLoggedIn"), "displayOrder", "ASC"));
						ar.putObject("registration", crsApp.getGuestRegistration(registrationID));
					}

					ar.putObject("conference", crsApp.getConference((String) ctx.getSessionValue("eventLoggedIn")));

					ar.addCollection("answers", crsApp.listRegistrationAnswers(registrationID));

					ar.putValue("registrationID", ctx.getInputString("registrationID"));

					ctx.setReturnValue(ar);

					ctx.goToView("editRegistrationQuestions");
				} else {
					ar.putValue("errorMsg", "The registration could not located, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "listRegistrations");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void editReport(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else {
				if (ctx.getInputString("reportID") != null) {
					String reportID = ctx.getInputString("reportID");
					ar.putObject("report", crsApp.getReport(reportID));
					ctx.setReturnValue(ar);
					ctx.goToView("editReportDetails");
				} else {
					ar.putValue("errorMsg", "The report could not located, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "listReports");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}

	//Created: 10/29/2002 DMB
	//default error page handler
	public void goToErrorPage(ActionContext ctx, Exception e, String methodName) {
		e.printStackTrace();
		ActionResults ar = new ActionResults();
		String exceptionText = e + "<BR>\n"; //+ e.getStackTrace()[0];
		//for(int i=1; !e.getStackTrace()[i].toString().startsWith("sun"); i++)
		//  exceptionText += "<BR>\n" + e.getStackTrace()[i];
		ar.putValue("exceptionText", exceptionText);
		ctx.setReturnValue(ar);
		ctx.goToErrorView();
		log(Priority.ERROR, "Failed to perform " + methodName + "().", e);
	}

	public void init() {
		log(Priority.DEBUG, "CRSAdmin.init()");
		super.setViewsFile(getServletContext().getRealPath(VIEWS_FILE));
		super.setDefaultAction(DEFAULT_ACTION);
		super.setDefaultErrorView(DEFAULT_ERROR_VIEW);
	}

	public void listCommonQuestions(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				String conferenceID = (String) ctx.getSessionValue("eventLoggedIn");
				int orderCol = 0;
				String order = "";
				String view = "";
				String[] orderFields = { "body", "answerType" };

				if (ctx.getInputString("orderCol") != null)
					orderCol = Integer.parseInt(ctx.getInputString("orderCol"));
				else
					orderCol = 0;

				if (ctx.getInputString("order") != null && ctx.getInputString("order").equals("DESC"))
					order = "DESC";
				else
					order = "ASC";

				if (ctx.getInputString("view") != null)
					view = ctx.getInputString("view");
				else
					view = "student";

				ar.putValue("orderCol", String.valueOf(orderCol));
				ar.putValue("order", order);

				ar.addCollection("Questions", crsApp.listCommonQuestions(orderFields[orderCol], order));
				ar.putObject("conference", crsApp.getConference(conferenceID));

				ctx.setReturnValue(ar);
				ctx.goToView("listCommonQuestions");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "listCustomItems");
		}
	}

	public void listConferences(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			//get a listing of all the conferences
			String currentRegion = "";
			String view = "";
			int orderCol = 0;
			String order = "";
			String[] orderFields = { "name", "preRegStart", "preRegEnd" };

			if (ctx.getInputString("currentRegion") != null)
				currentRegion = ctx.getInputString("currentRegion");
			else
				currentRegion = "ALL";

			if (ctx.getInputString("view") != null)
				view = ctx.getInputString("view");
			else
				view = "current";

			if (ctx.getInputString("orderCol") != null)
				orderCol = Integer.parseInt(ctx.getInputString("orderCol"));
			else
				orderCol = 0;

			if (ctx.getInputString("order") != null && ctx.getInputString("order").equals("DESC"))
				order = "DESC";
			else
				order = "ASC";

			ar.putValue("currentRegion", currentRegion);
			ar.putValue("view", view);
			ar.putValue("orderCol", String.valueOf(orderCol));
			ar.putValue("order", order);

			if (view.equals("current")) {
				ar.addCollection("Conferences", crsApp.listCurrentConferences(currentRegion, orderFields[orderCol], order));
			} else if (view.equals("archived")) {
				ar.addCollection("Conferences", crsApp.listArchivedConferences(currentRegion, orderFields[orderCol], order));
			} else {
				ar.addCollection("Conferences", crsApp.listConferences(currentRegion, orderFields[orderCol], order));
			}

			ctx.setSessionValue("eventLoggedIn", null);
			ctx.setSessionValue("authLevel", null);
			ctx.setReturnValue(ar);
			ctx.goToView("listConferences");
		} catch (Exception e) {
			goToErrorPage(ctx, e, "listConferences");
		}
	}
	public void listCustomItems(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[0], ctx)) {
				login(ctx);
			} else {
				String conferenceID = (String) ctx.getSessionValue("eventLoggedIn");
				int orderCol = 0;
				String order = "";
				String[] orderFields = { "displayOrder", "title" };

				if (ctx.getInputString("orderCol") != null)
					orderCol = Integer.parseInt(ctx.getInputString("orderCol"));
				else
					orderCol = 0;

				if (ctx.getInputString("order") != null && ctx.getInputString("order").equals("DESC"))
					order = "DESC";
				else
					order = "ASC";

				ar.putValue("orderCol", String.valueOf(orderCol));
				ar.putValue("order", order);

				ar.addCollection("Items", crsApp.listCustomItems(conferenceID, orderFields[orderCol], order));
				ar.putObject("conference", crsApp.getConference(conferenceID));

				ctx.setReturnValue(ar);
				ctx.goToView("listCustomItems");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "listCustomItems");
		}
	}

	public void listMerchandise(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[0], ctx)) {
				login(ctx);
			} else {
				String conferenceID = (String) ctx.getSessionValue("eventLoggedIn");
				String view = "";
				int orderCol = 0;
				String order = "";
				String[] orderFields = { "displayOrder", "name", "amount", "note", "required" };

				if (ctx.getInputString("view") != null)
					view = ctx.getInputString("view");
				else
					view = "student";

				if (ctx.getInputString("orderCol") != null)
					orderCol = Integer.parseInt(ctx.getInputString("orderCol"));
				else
					orderCol = 0;

				if (ctx.getInputString("order") != null && ctx.getInputString("order").equals("DESC"))
					order = "DESC";
				else
					order = "ASC";

				ar.putValue("view", view);
				ar.putValue("orderCol", String.valueOf(orderCol));
				ar.putValue("order", order);

				if (view.equals("guest")) {
					ar.addCollection("Merchandise", crsApp.listGuestMerchandise(conferenceID, orderFields[orderCol], order));
				} else if (view.equals("staff")) {
					ar.addCollection("Merchandise", crsApp.listStaffMerchandise(conferenceID, orderFields[orderCol], order));
				} else {
					ar.addCollection("Merchandise", crsApp.listStudentMerchandise(conferenceID, orderFields[orderCol], order));
				}
				ar.putObject("conference", crsApp.getConference(conferenceID));

				ctx.setReturnValue(ar);
				ctx.goToView("listMerchandise");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "listMerchandise");
		}
	}

	public void listQuestions(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[0], ctx)) {
				login(ctx);
			} else {
				String conferenceID = (String) ctx.getSessionValue("eventLoggedIn");
				String view = "";
				int orderCol = 0;
				String order = "";
				String[] orderFields = { "displayOrder", "crs_QuestionText.body", "QuestionText.answerType", "required", "crs_QuestionText.status" };

				if (ctx.getInputString("view") != null)
					view = ctx.getInputString("view");
				else
					view = "student";

				if (ctx.getInputString("orderCol") != null)
					orderCol = Integer.parseInt(ctx.getInputString("orderCol"));
				else
					orderCol = 0;

				if (ctx.getInputString("order") != null && ctx.getInputString("order").equals("DESC"))
					order = "DESC";
				else
					order = "ASC";

				ar.putValue("view", view);
				ar.putValue("orderCol", String.valueOf(orderCol));
				ar.putValue("order", order);

				if (view.equals("guest")) {
					ar.addCollection("Questions", crsApp.listGuestQuestions(conferenceID, orderFields[orderCol], order));
				} else if (view.equals("staff")) {
					ar.addCollection("Questions", crsApp.listStaffQuestions(conferenceID, orderFields[orderCol], order));
				} else {
					ar.addCollection("Questions", crsApp.listStudentQuestions(conferenceID, orderFields[orderCol], order));
				}
				ar.putObject("conference", crsApp.getConference(conferenceID));

				ctx.setReturnValue(ar);
				ctx.goToView("listQuestions");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "listQuestions");
		}
	}

	public void listReports(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[0], ctx)) {
				login(ctx);
			} else {
				String view = "";

				if (ctx.getInputString("view") != null)
					view = ctx.getInputString("view");
				else
					view = "0";

				ar.putValue("view", view);

				if (view.equals("2")) {
					ar.addCollection("reports", crsApp.listStaffReports());
				} else if (view.equals("1")) {
					ar.addCollection("reports", crsApp.listStudentReports());
				} else if (view.equals("3")) {
					ar.addCollection("reports", crsApp.listGuestReports());
				} else {
					ar.addCollection("reports", crsApp.listGeneralReports());
				}

				ctx.setReturnValue(ar);
				ctx.goToView("listReports");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "createConference");
		}
	}

	public void login(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null && ctx.getInputString("conferenceID") == null && ctx.getSessionValue("levelRequired") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else {
				String conferenceID = ctx.getSessionValue("eventLoggedIn") == null ? ctx.getInputString("conferenceID") : (String) ctx.getSessionValue("eventLoggedIn");
				conferenceID = ctx.getInputString("conferenceID") == null ? conferenceID : ctx.getInputString("conferenceID");
				ctx.setSessionValue("eventLoggedIn", conferenceID);
				ar.putObject("conference", crsApp.getConference(conferenceID));
				ctx.setReturnValue(ar);
				ctx.goToView("challengeLogin");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}

	public void lookupAdvancedRegistrations(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[0], ctx)) {
				login(ctx);
			} else if(ctx.getSessionValue("lookupURL") != null && !ctx.getLastLastAction().equals("lookupRegistrations") && !ctx.getLastLastAction().equals("lookupAdvancedRegistrations")) {
				String url = (String)ctx.getSessionValue("lookupURL");
				ctx.setSessionValue("lookupURL", null);
				ctx.getResponse().sendRedirect(url);
			} else {
				String conferenceID = (String) ctx.getSessionValue("eventLoggedIn");
				String view = "";
				int orderCol;
				String order = "";
				int offset;
				int size;
				String[] orderFields = { "lastName, firstName", "gender, lastName, firstName", "campus, lastName, firstName", "preRegistered, lastName, firstName", "registrationDate, lastName, firstName" };
				ctx.setSessionValue("lookupURL", javax.servlet.http.HttpUtils.getRequestURL(ctx.getRequest()).toString() + "?" + ctx.getRequest().getQueryString());

				if (ctx.getInputString("view") != null)
					view = ctx.getInputString("view");
				else
					view = "student";

				if (ctx.getInputString("orderCol") != null)
					orderCol = Integer.parseInt(ctx.getInputString("orderCol"));
				else
					orderCol = 0;

				if (ctx.getInputString("offset") != null)
					offset = Integer.parseInt(ctx.getInputString("offset"));
				else
					offset = 1;

				if (ctx.getInputString("size") != null)
					size = Integer.parseInt(ctx.getInputString("size"));
				else
					size = 10;

				if (ctx.getInputString("order") != null && ctx.getInputString("order").equals("DESC"))
					order = "DESC";
				else
					order = "ASC";

				ar.putValue("view", view);
				ar.putValue("orderCol", String.valueOf(orderCol));
				ar.putValue("offset", String.valueOf(offset));
				ar.putValue("size", String.valueOf(size));
				ar.putValue("order", order);

				String firstName = ctx.getInputString("firstName") == null ? "" : ctx.getInputString("firstName");
				ar.putValue("firstName", firstName);
				String lastName = ctx.getInputString("lastName") == null ? "" : ctx.getInputString("lastName");
				ar.putValue("lastName", lastName);
				String region = ctx.getInputString("region") == null ? "" : ctx.getInputString("region");
				ar.putValue("region", region);
				String state = ctx.getInputString("state") == null ? "" : ctx.getInputString("state");
				ar.putValue("state", state);
				String localLevelID = ctx.getInputString("localLevelID") == null ? "" : ctx.getInputString("localLevelID");
				ar.putValue("localLevelID", localLevelID);
				String Campus = ctx.getInputString("Campus") == null ? "" : ctx.getInputString("Campus");
				ar.putValue("Campus", Campus);

				if (!"".equals(firstName) || !"".equals(lastName) || !"".equals(region) || !"".equals(Campus) || !"".equals(state) || !"".equals(localLevelID)) {
					Vector regs = new Vector(crsApp.searchRegistrationsAdvanced(firstName, lastName, region, state, localLevelID, Campus.replaceAll("'","''"), view, conferenceID, orderFields[orderCol], order, offset, size));
					ar.putValue("maxSize", (regs.remove(0)).toString());
					ar.addCollection("Registrations", regs);
				}

				ar.addCollection("localLevels", new org.alt60m.ministry.model.dbio.LocalLevel().selectList("name <> '' ORDER BY name ASC"));

				ar.putObject("conference", crsApp.getConference(conferenceID));

				ctx.setReturnValue(ar);
				ctx.goToView("lookupAdvancedRegistration");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "listRegistrations");
		}
	}
	public void lookupPerson(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[0], ctx)) {
				login(ctx);
			} else {
				int orderCol = 0;
				String order = "";
				String[] orderFields = { "firstName", "lastName" };
				int offset;
				int size;

				if (ctx.getInputString("orderCol") != null)
					orderCol = Integer.parseInt(ctx.getInputString("orderCol"));
				else
					orderCol = 0;

				if (ctx.getInputString("order") != null && ctx.getInputString("order").equals("DESC"))
					order = "DESC";
				else
					order = "ASC";

				if (ctx.getInputString("offset") != null)
					offset = Integer.parseInt(ctx.getInputString("offset"));
				else
					offset = 1;

				if (ctx.getInputString("size") != null)
					size = Integer.parseInt(ctx.getInputString("size"));
				else
					size = 10;

				if (ctx.getInputString("nextVar") != null)
					ar.putValue("nextVar", ctx.getInputString("nextVar"));
				else
					ar.putValue("nextVar", "personID");

				ar.putValue("offset", String.valueOf(offset));
				ar.putValue("size", String.valueOf(size));
				ar.putValue("orderCol", String.valueOf(orderCol));
				ar.putValue("order", order);
				ar.putValue("nextAction", ctx.getInputString("nextAction"));

				String firstName = ctx.getInputString("firstName") == null ? "" : ctx.getInputString("firstName");
				String lastName = ctx.getInputString("lastName") == null ? "" : ctx.getInputString("lastName");
				ar.putValue("firstName", firstName);
				ar.putValue("lastName", lastName);
				ar.putValue("lookupMessage", ctx.getInputString("lookupMessage"));
				if (lastName != "") {
					Vector sp = new Vector(crsApp.searchPersons(firstName, lastName, orderFields[orderCol], order, offset, size));
					ar.putValue("maxSize", (sp.remove(0)).toString());
					ar.addCollection("persons", sp);
				}
				ar.addHashtable("request", ctx.getHashedRequest());
				ctx.setReturnValue(ar);
				ctx.goToView("lookupPerson");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showPerson");
		}

	}

	public void lookupRegistrations(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[0], ctx)) {
				login(ctx);
			} else if(ctx.getSessionValue("lookupURL") != null && !ctx.getLastLastAction().equals("lookupRegistrations") && !ctx.getLastLastAction().equals("lookupAdvancedRegistrations")) {
				String url = (String)ctx.getSessionValue("lookupURL");
				ctx.setSessionValue("lookupURL", null);
				ctx.getResponse().sendRedirect(url);
			} else {
				String conferenceID = (String) ctx.getSessionValue("eventLoggedIn");
				String view = "";
				int orderCol;
				String order = "";
				int offset;
				int size;
				String[] orderFields = { "lastName, firstName", "gender, lastName, firstName", "campus, lastName, firstName", "preRegistered, lastName, firstName", "registrationDate, lastName, firstName" };
				ctx.setSessionValue("lookupURL", javax.servlet.http.HttpUtils.getRequestURL(ctx.getRequest()).toString() + "?" + ctx.getRequest().getQueryString());

				if (ctx.getInputString("view") != null)
					view = ctx.getInputString("view");
				else
					view = "student";

				if (ctx.getInputString("orderCol") != null)
					orderCol = Integer.parseInt(ctx.getInputString("orderCol"));
				else
					orderCol = 0;

				if (ctx.getInputString("offset") != null)
					offset = Integer.parseInt(ctx.getInputString("offset"));
				else
					offset = 1;

				if (ctx.getInputString("size") != null)
					size = Integer.parseInt(ctx.getInputString("size"));
				else
					size = 10;

				if (ctx.getInputString("order") != null && ctx.getInputString("order").equals("DESC"))
					order = "DESC";
				else
					order = "ASC";

				ar.putValue("view", view);
				ar.putValue("orderCol", String.valueOf(orderCol));
				ar.putValue("offset", String.valueOf(offset));
				ar.putValue("size", String.valueOf(size));
				ar.putValue("order", order);

				String firstName = ctx.getInputString("firstName") == null ? "" : ctx.getInputString("firstName");
				String lastName = ctx.getInputString("lastName") == null ? "" : ctx.getInputString("lastName");
				ar.putValue("firstName", firstName);
				ar.putValue("lastName", lastName);

				if (lastName != "") {
					Vector regs = new Vector(crsApp.searchRegistrationsByName(firstName, lastName, view, conferenceID, orderFields[orderCol], order, offset, size));
					ar.putValue("maxSize", (regs.remove(0)).toString());
					ar.addCollection("Registrations", regs);
				}
				ar.putObject("conference", crsApp.getConference(conferenceID));

				ctx.setReturnValue(ar);
				ctx.goToView("lookupRegistration");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "listRegistrations");
		}
	}
	public void newCustomItem(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				CustomItem ci = new CustomItem();
				ar.putObject("item", ci);
				ctx.setReturnValue(ar);
				ctx.goToView("editCustomItemDetails");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void newMerchandise(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				Merchandise m = new Merchandise();
				m.setRegistrationType(ctx.getInputString("view"));
				ar.putObject("merchandise", m);
				ctx.setReturnValue(ar);
				ctx.goToView("editMerchandiseDetails");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void newQuestion(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				Question q = new Question();
				QuestionText qt = new QuestionText();
				qt.setStatus("custom");
				q.setQuestionText(qt);
				q.setRegistrationType(ctx.getInputString("view"));
				ar.putObject("question", q);
				ar.putValue("order", ctx.getInputString("order"));
				ar.putValue("orderCol", ctx.getInputString("orderCol"));
				ctx.setReturnValue(ar);
				ctx.goToView("editQuestionDetails");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void newRegistration(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else if (ctx.getInputString("foundID") == null) {
				ar.putValue("nextAction", "newRegistration");
				ar.putValue("nextVar", "foundID");
				ar.putValue("lookupMessage", "Select the person to be registered");
				ar.addHashtable("request", ctx.getHashedRequest());
				ctx.setReturnValue(ar);
				ctx.goToView("lookupPerson");
			} else {
				Registration r = crsApp.getRegistrationByPersonID(ctx.getInputString("foundID"), (String) ctx.getSessionValue("eventLoggedIn"));
				int registrationID = r.getRegistrationID();
				if (r.isPKEmpty()) { // If new registration, create it and assoc the person
					Person p = crsApp.getPerson(ctx.getInputString("foundID"));

					Conference c = crsApp.getConference((String) ctx.getSessionValue("eventLoggedIn"));
					registrationID = crsApp.createRegistration(ctx.getInputString("type") == null || ctx.getInputString("type").equals("") ? "student" : ctx.getInputString("type"), p, c);
					r.setRegistrationID(registrationID);
					r.select();

					if (r.getRegistrationType().equals("staff"))
						ar.putObject("registration", crsApp.getStaffRegistration(registrationID));
					else if (r.getRegistrationType().equals("student"))
						ar.putObject("registration", crsApp.getStudentRegistration(registrationID));
					else if (r.getRegistrationType().equals("guest"))
						ar.putObject("registration", crsApp.getGuestRegistration(registrationID));

					// Add full conference payment
					crsApp.updatePayments(String.valueOf(registrationID));

					ar.putObject("conference", crsApp.getConference((String) ctx.getSessionValue("eventLoggedIn")));

					ctx.setReturnValue(ar);

					if (r.getRegistrationType().equals("staff")) {
						ctx.goToView("editStaffRegistration");
					} else if (r.getRegistrationType().equals("student")) {
						ctx.goToView("editStudentRegistration");
					} else if (r.getRegistrationType().equals("guest")) {
						ctx.goToView("editGuestRegistration");
					}
				} else { // throw error, make them look for someone else
					ar.putValue("errorMsg", r.getPerson().getFirstName() + " " + r.getPerson().getLastName() + " has previously registered for this conference as a " + r.getRegistrationType() + ". Hit back to find a different person, or continue to return to the Manage Registrants page.");
					ar.putValue("nextAction", "lookupRegistrations");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showPerson");
		}
	}

	public void newReport(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else {
				Report r = new Report();
				ar.putObject("report", r);
				ctx.setReturnValue(ar);
				ctx.goToView("editReportDetails");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void outputXML(javax.servlet.http.HttpServletResponse res, String _XML) throws Exception {
		res.setContentType("text/xml");
		java.io.PrintWriter out = res.getWriter();

		out.println(_XML);
		out.flush();
	}

	public void prepDownload(ActionContext ctx) {
		ActionResults ar = new ActionResults("adminPrepDownload");
		String eventId = (String) ctx.getSessionValue("eventLoggedIn");
		try {
			String baseFilePath = getServletContext().getRealPath(APP_FOLDER);
			new CRSImportExport(baseFilePath).initFolders(); //Makes sure that the import/export directories exsist.
			ar.putObject("conference", crsApp.getConference((String) ctx.getSessionValue("eventLoggedIn")));
			ar.putValue("ConferenceID", eventId);
			ctx.setReturnValue(ar);
			ctx.goToView("prepDownload");
		} catch (Exception e) {
			goToErrorPage(ctx, e, "adminPrepDownload");
		}
	}

	public void reload() {
		super.setViewsFile(getServletContext().getRealPath(VIEWS_FILE));
	}

	public void reportXML(ActionContext ctx) {
		try {
			int offset;
			int size;
			int orderCol;
			String order = "";

			if (ctx.getInputString("orderCol") != null)
				orderCol = Integer.parseInt(ctx.getInputString("orderCol"));
			else
				orderCol = 0;

			if (ctx.getInputString("offset") != null)
				offset = Integer.parseInt(ctx.getInputString("offset"));
			else
				offset = 1;

			if (ctx.getInputString("size") != null)
				size = Integer.parseInt(ctx.getInputString("size"));
			else
				size = 10;

			if (ctx.getInputString("order") != null && ctx.getInputString("order").equals("DESC"))
				order = "DESC";
			else
				order = "ASC";

			outputXML(ctx.getResponse(), crsApp.reportXML(ctx.getInputString("reportID"), ctx.getInputString("conferenceID"), orderCol, order, offset, size));
		} catch (Exception e) {
			goToErrorPage(ctx, e, "reportXML");
		}
	}
	/********************************************************************************/
	//Created: 10/29/2002 DMB
	//Generates an exception for testing purposes.
	public void sampleError(ActionContext ctx) {
		try {
			String test = null;
			if (test.equals("EXCEPTION! OUCH"));
		} catch (Exception e) {
			goToErrorPage(ctx, e, "sampleError");
		}
	}

	public void saveConferenceDetails(ActionContext ctx) {
		try {
			if (ctx.getSessionValue("eventLoggedIn") == null && !"true".equals(ctx.getSessionValue("newEvent"))) {
				adminHome(ctx);
			} else if (ctx.getSessionValue("eventLoggedIn") == null) {
				int conferenceID = crsApp.createConference(ctx.getHashedRequest());
				ctx.setSessionValue("eventLoggedIn", String.valueOf(conferenceID));
				ctx.setSessionValue("authLevel", AUTH_LEVELS[1]);
				listCustomItems(ctx);
			} else {
				if (crsApp.saveConference(ctx.getHashedRequest())) {
					if ("true".equals(ctx.getSessionValue("newEvent")))
						listCustomItems(ctx);
					else
						showConference(ctx);
				} else {
					ActionResults ar = new ActionResults();
					ar.putValue("errorMsg", "The conference could not save, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "adminHome");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void saveCustomItem(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				if (crsApp.saveCustomItem(ctx.getHashedRequest())) {
					listCustomItems(ctx);
				} else {
					ar.putValue("errorMsg", "The custom item could not save, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "listCustomItems");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void saveCustomItems(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				int itemSize = ctx.getInputString("itemSize") == null ? 0 : Integer.parseInt(ctx.getInputString("itemSize"));
				for (int i = 0; i < itemSize; i++) {
					Hashtable ci = new Hashtable();
					ci.put("CustomItemID", ctx.getInputString(i + "CustomItemID"));
					ci.put("ConferenceID", ctx.getSessionValue("eventLoggedIn"));
					ci.put("DisplayOrder", ctx.getInputString(i + "DisplayOrder"));
					crsApp.saveCustomItem(ci);
				}
				if (ctx.getSessionValue("newEvent") != null && ctx.getSessionValue("newEvent").equals("true"))
					editFinancialDetails(ctx);
				else
					showConference(ctx);
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "editCustomItem");
		}
	}
	public void saveDisplayOptions(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				if (crsApp.saveConference(ctx.getHashedRequest())) {
					showConference(ctx);
				} else {
					ar.putValue("errorMsg", "The conference could not save, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "adminHome");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void saveFinancialDetails(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				if (crsApp.saveConference(ctx.getHashedRequest())) {
					if ("true".equals(ctx.getSessionValue("newEvent")))
						listMerchandise(ctx);
					else
						showConference(ctx);
				} else {
					ar.putValue("errorMsg", "The conference could not save, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "adminHome");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void saveMerchandise(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				int merchandiseSize = Integer.parseInt(ctx.getInputString("merchandiseSize") != null ? ctx.getInputString("merchandiseSize") : "0");
				for (int i = 0; i < merchandiseSize; i++) {
					Hashtable m = new Hashtable();
					m.put("MerchandiseID", ctx.getInputString(i + "MerchandiseID"));
					m.put("DisplayOrder", ctx.getInputString(i + "DisplayOrder"));
					crsApp.saveMerchandise(m);
				}
				if (ctx.getSessionValue("newEvent") != null && ctx.getSessionValue("newEvent").equals("true"))
					listQuestions(ctx);
				else
					showConference(ctx);
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "editMerchandise");
		}
	}
	public void saveMerchandiseDetails(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				Hashtable req = ctx.getHashedRequest();
				req.remove("view");
				req.remove("action");
				req.put("ConferenceID", ctx.getSessionValue("eventLoggedIn"));
				if (crsApp.saveMerchandise(req)) {
					listMerchandise(ctx);
				} else {
					ar.putValue("errorMsg", "The merchandise could not save, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "adminHome");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void savePaymentDetails(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				adminHome(ctx);
			} else if (ctx.getInputString("registrationID") == null || ctx.getInputString("PaymentID") == null) {
				ar.putValue("errorMsg", "There was a problem saving your payment. Please try again.");
				ar.putValue("nextAction", "showConference");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else {
				Hashtable req = ctx.getHashedRequest();
				req.put("RegistrationID", ctx.getInputString("registrationID"));
				req.remove("registrationID");
				if (crsApp.savePayment(req)) {
					editRegistrationPayments(ctx);
				} else {
					ar.putValue("errorMsg", "The payment could not save, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "showConference");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void saveQuestionDetails(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				boolean retVal = false;

				if ("0".equals(ctx.getInputString("QuestionID"))) {
					String[] RegistrationTypes = ctx.getInputStringArray("RegistrationTypes");

					for (int i = 0; RegistrationTypes != null && i < RegistrationTypes.length; i++) {
						Hashtable tempQuestion = ctx.getHashedRequest();
						tempQuestion.put("RegistrationType", RegistrationTypes[i]);
						crsApp.saveQuestion(tempQuestion);
					}
				} else {
					crsApp.saveQuestion(ctx.getHashedRequest());
				}
				listQuestions(ctx);
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void saveQuestions(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				int questionSize = ctx.getInputString("questionSize") == null ? 0 : Integer.parseInt(ctx.getInputString("questionSize"));
				for (int i = 0; i < questionSize; i++) {
					Hashtable q = new Hashtable();
					q.put("QuestionID", ctx.getInputString(i + "QuestionID"));
					q.put("DisplayOrder", ctx.getInputString(i + "DisplayOrder"));
					crsApp.updateQuestion(q);
				}
				if (ctx.getSessionValue("newEvent") != null && ctx.getSessionValue("newEvent").equals("true"))
					editDisplayOptions(ctx);
				else
					showConference(ctx);
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "editQuestion");
		}
	}
	public void saveRegistration(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else if (ctx.getInputString("RegistrationID") == null) {
				ar.putValue("errorMsg", "regID not found");
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else {
				boolean success = false;
				String registrationID = ctx.getInputString("registrationID");
				Registration r = crsApp.getRegistration(registrationID);

				if (r.getRegistrationType().equals("staff")) {
					success = crsApp.saveStaffRegistration(ctx.getHashedRequest());
				} else if (r.getRegistrationType().equals("student")) {
					success = crsApp.saveStudentRegistration(ctx.getHashedRequest());
				} else if (r.getRegistrationType().equals("guest")) {
					success = crsApp.saveGuestRegistration(ctx.getHashedRequest());
				}

				if (success) {
					showRegistration(ctx);
				} else {
					ar.putValue("errorMsg", "The registration could not save, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "adminHome");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void saveChildRegistration(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else if (ctx.getInputString("ChildRegistrationID") == null) {
				ar.putValue("errorMsg", "regID not found");
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else {
				boolean success = false;
				String childRegistrationID = ctx.getInputString("ChildRegistrationID");
				ChildRegistration r = crsApp.getChildRegistration(childRegistrationID);

				success = crsApp.saveChildRegistration(ctx.getHashedRequest());

				if (success) {
					showChildRegistration(ctx);
				} else {
					ar.putValue("errorMsg", "The registration could not save, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "adminHome");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void saveRegistrationMerchandise(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				if (ctx.getInputString("registrationID") != null) {
					Registration r = crsApp.getRegistration(ctx.getInputString("registrationID"));

					MerchandiseChoice mc = new MerchandiseChoice();
					mc.setRegistrationID(r.getRegistrationID());
					mc.delete();

					if (ctx.getInputStringArray("choices") != null) {
						String[] choices = ctx.getInputStringArray("choices");

						for (int i = 0; i < choices.length; i++) {
							Merchandise m = crsApp.getMerchandise(choices[i]);
							r.assocMerchandise(m);
						}
					}
					showRegistration(ctx);
				} else {
					ar.putValue("errorMsg", "The registration could not located, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "listRegistrations");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "editMerchandise");
		}
	}

	public void saveRegistrationQuestions(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				if (ctx.getInputString("registrationID") != null) {
					String registrationID = ctx.getInputString("registrationID");
					Collection questions = new Vector();
					Registration r = crsApp.getRegistration(registrationID);

					if (r.getRegistrationType().equals("staff")) {
						questions = crsApp.listStaffQuestions((String) ctx.getSessionValue("eventLoggedIn"), "displayOrder", "ASC");
					} else if (r.getRegistrationType().equals("student")) {
						questions = crsApp.listStudentQuestions((String) ctx.getSessionValue("eventLoggedIn"), "displayOrder", "ASC");
					} else if (r.getRegistrationType().equals("guest")) {
						questions = crsApp.listGuestQuestions((String) ctx.getSessionValue("eventLoggedIn"), "displayOrder", "ASC");
					}

					Iterator qi = questions.iterator();

					while (qi.hasNext()) {
						Question q = (Question) qi.next();
						System.out.println(q.getAnswerType());
						if (!q.getAnswerType().equals("divider") && !q.getAnswerType().equals("info") && !q.getAnswerType().equals("hide")) {
							Hashtable values = new Hashtable();
							String answer = ctx.getInputString(String.valueOf(q.getQuestionID()));
							answer = answer == null ? "" : answer;
							if (q.getAnswerType().equals("checkbox"))
								answer = "Yes".equals(answer) ? "Yes" : "No";
							values.put("Body", answer);
							values.put("QuestionID", String.valueOf(q.getQuestionID()));
							values.put("RegistrationID", registrationID);
							crsApp.saveAnswer(values);
						}
					}
					showRegistration(ctx);
				} else {
					ar.putValue("errorMsg", "The registration could not located, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "listRegistrations");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}
	public void saveReport(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else {
				if (crsApp.saveReport(ctx.getHashedRequest())) {
					listReports(ctx);
				} else {
					ar.putValue("errorMsg", "The report could not save, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "listReports");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}

	public void showConference(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null && ctx.getInputString("conferenceID") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[0], ctx)) {
				login(ctx);
			} else {
				String conferenceID = ctx.getSessionValue("eventLoggedIn") == null ? ctx.getInputString("conferenceID") : (String) ctx.getSessionValue("eventLoggedIn");
				conferenceID = ctx.getInputString("conferenceID") == null ? conferenceID : ctx.getInputString("conferenceID");
				ar.putObject("conference", crsApp.getConference(conferenceID));
				ar.putValue("registered", String.valueOf(crsApp.countRegistrations(conferenceID)));
				ar.putValue("registeredStaff", String.valueOf(crsApp.countStaffRegistrations(conferenceID)));
				ar.putValue("registeredStudents", String.valueOf(crsApp.countStudentRegistrations(conferenceID)));
				ar.putValue("registeredGuests", String.valueOf(crsApp.countGuestRegistrations(conferenceID)));

				// Set session values to remember logged in conference
				ctx.setSessionValue("eventLoggedIn", conferenceID);
				ctx.setSessionValue("newEvent", null);

				ctx.setReturnValue(ar);
				ctx.goToView("showConference");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}

	public void showRegistration(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[0], ctx)) {
				login(ctx);
			} else {
				String registrationID = "";
				if (ctx.getInputString("registrationID") != null) {
					registrationID = ctx.getInputString("registrationID");

					Registration r = crsApp.getRegistration(registrationID);
					if (r.getRegistrationType().equals("staff"))
						ar.putObject("registration", crsApp.getStaffRegistration(registrationID));
					else if (r.getRegistrationType().equals("student"))
						ar.putObject("registration", crsApp.getStudentRegistration(registrationID));
					else if (r.getRegistrationType().equals("guest"))
						ar.putObject("registration", crsApp.getGuestRegistration(registrationID));

					ar.putObject("conference", crsApp.getConference((String) ctx.getSessionValue("eventLoggedIn")));

					ar.addCollection("answers", crsApp.listRegistrationAnswers(registrationID));
					ar.addCollection("merchandise", crsApp.listRegistrationMerchandise(registrationID, "displayOrder", "DESC"));
					ar.addCollection("payments", crsApp.listRegistrationPayments(registrationID, "paymentDate", "ASC"));
					ctx.setReturnValue(ar);

					if (r.getRegistrationType().equals("staff")) {
						ar.addCollection("questions", crsApp.listStaffQuestions((String) ctx.getSessionValue("eventLoggedIn"), "displayOrder", "ASC"));
						ar.addCollection("childRegistrations", crsApp.listChildRegistrations(registrationID));
						ctx.goToView("showStaffRegistration");
					} else if (r.getRegistrationType().equals("student")) {
						ar.addCollection("questions", crsApp.listStudentQuestions((String) ctx.getSessionValue("eventLoggedIn"), "displayOrder", "ASC"));
						ctx.goToView("showStudentRegistration");
					} else if (r.getRegistrationType().equals("guest")) {
						ar.addCollection("questions", crsApp.listGuestQuestions((String) ctx.getSessionValue("eventLoggedIn"), "displayOrder", "ASC"));
						ctx.goToView("showGuestRegistration");
					}
				} else {
					ar.putValue("errorMsg", "The registration could not located, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "listRegistrations");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}

	public void showChildRegistration(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[0], ctx)) {
				login(ctx);
			} else {
				String childRegistrationID = "";
				if (ctx.getInputString("childRegistrationID") != null) {
					childRegistrationID = ctx.getInputString("childRegistrationID");

					ChildRegistration cr = crsApp.getChildRegistration(childRegistrationID);
					ar.putObject("registration", cr);
					ar.putObject("parentregistration", crsApp.getRegistration(cr.getRegistrationID()));
					ar.putObject("conference", crsApp.getConference((String) ctx.getSessionValue("eventLoggedIn")));

					ctx.setReturnValue(ar);

					ctx.goToView("showChildRegistration");
				} else {
					ar.putValue("errorMsg", "The registration could not located, please try again or start over by hitting continue.");
					ar.putValue("nextAction", "listRegistrations");
					ctx.setReturnValue(ar);
					ctx.goToView("error");
				}
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "showConference");
		}
	}

	public void showReport(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[0], ctx)) {
				login(ctx);
			} else {
				int orderCol;
				String order = "";
				int offset;
				int size;

				if (ctx.getInputString("orderCol") != null)
					orderCol = Integer.parseInt(ctx.getInputString("orderCol"));
				else
					orderCol = 0;

				if (ctx.getInputString("offset") != null)
					offset = Integer.parseInt(ctx.getInputString("offset"));
				else
					offset = 1;

				if (ctx.getInputString("size") != null)
					size = Integer.parseInt(ctx.getInputString("size"));
				else
					size = 10;

				if (ctx.getInputString("order") != null && ctx.getInputString("order").equals("DESC"))
					order = "DESC";
				else
					order = "ASC";

				ar.putValue("orderCol", String.valueOf(orderCol));
				ar.putValue("offset", String.valueOf(offset));
				ar.putValue("size", String.valueOf(size));
				ar.putValue("maxSize", String.valueOf(crsApp.countReport(ctx.getInputString("reportID").toString(), (String) ctx.getSessionValue("eventLoggedIn"))));
				ar.putValue("order", order);

				ar.putObject("conference", crsApp.getConference((String) ctx.getSessionValue("eventLoggedIn")));
				ar.putObject("report", crsApp.getReport(ctx.getInputString("reportID")));

				ctx.setReturnValue(ar);
				ctx.goToView("showReport");
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "createConference");
		}
	}
	public void updateCustomItemOrder(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				int itemSize = Integer.parseInt(ctx.getInputString("itemSize"));
				for (int i = 0; i < itemSize; i++) {
					Hashtable ci = new Hashtable();
					ci.put("CustomItemID", ctx.getInputString(i + "CustomItemID"));
					ci.put("ConferenceID", ctx.getSessionValue("eventLoggedIn"));
					ci.put("DisplayOrder", ctx.getInputString(i + "DisplayOrder"));
					crsApp.saveCustomItem(ci);
				}
				listCustomItems(ctx);
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "editCustomItem");
		}
	}
	public void updateMerchandiseOrder(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				int merchandiseSize = Integer.parseInt(ctx.getInputString("merchandiseSize"));
				System.out.println("------> " + merchandiseSize);
				for (int i = 0; i < merchandiseSize; i++) {
					Hashtable m = new Hashtable();
					m.put("MerchandiseID", ctx.getInputString(i + "MerchandiseID"));
					m.put("DisplayOrder", ctx.getInputString(i + "DisplayOrder"));
					crsApp.updateMerchandise(m);
				}
				listMerchandise(ctx);
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "editMerchandise");
		}
	}
	public void updateQuestionOrder(ActionContext ctx) {
		try {
			ActionResults ar = new ActionResults();
			if (ctx.getSessionValue("eventLoggedIn") == null) {
				ar.putValue("errorMsg", ERR_conferenceNotFound);
				ar.putValue("nextAction", "adminHome");
				ctx.setReturnValue(ar);
				ctx.goToView("error");
			} else if (!authenticated(AUTH_LEVELS[1], ctx)) {
				login(ctx);
			} else {
				int questionSize = Integer.parseInt(ctx.getInputString("questionSize"));
				System.out.println("------> " + questionSize);
				for (int i = 0; i < questionSize; i++) {
					Hashtable q = new Hashtable();
					q.put("QuestionID", ctx.getInputString(i + "QuestionID"));
					q.put("DisplayOrder", ctx.getInputString(i + "DisplayOrder"));
					crsApp.updateQuestion(q);
				}
				listQuestions(ctx);
			}
		} catch (Exception e) {
			goToErrorPage(ctx, e, "editQuestion");
		}
	}

	public void uploadDB(ActionContext ctx) {
		ActionResults ar = new ActionResults("adminUpload");
		String eventId = (String) ctx.getSessionValue("eventLoggedIn");
		try {
			String baseFilePath = getServletContext().getRealPath(APP_FOLDER);
			CRSImportExport importExport = new CRSImportExport(baseFilePath);

			MultipartRequest multi = new MultipartRequest(ctx.getRequest(), importExport.getImportDirectory(), 20 * 1024 * 1024); // 20MB Max
			String name = (String) (multi.getFileNames().nextElement());
			java.io.File file = multi.getFile(name);
			System.out.println("File uploaded: " + file.getName());
			ar.addHashtable("Results", importExport.importFromAccess(file.getName(), (String) ctx.getSessionValue("eventLoggedIn")));

			ar.putObject("conference", crsApp.getConference(eventId));
			ar.putValue("ConferenceID", eventId);
			ctx.setReturnValue(ar);
			ctx.goToView("uploadFile");
		} catch (Exception e) {
			goToErrorPage(ctx, e, "adminUpload");
		}
	}

}